module.exports = {
    jwtSecret: process.env.JWT_SECRET || 'fallback_secret_change_this',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
    annualLeaveEntitlement: 21
};
