const pool = require('./config/database');
const bcrypt = require('bcryptjs');

const seedData = async () => {
    try {
        console.log('Seeding database...');

        const hashedPassword = await bcrypt.hash('admin123', 10);

        const [existingAdmin] = await pool.query('SELECT id FROM users WHERE email = ?', ['admin@company.com']);
        if (existingAdmin.length === 0) {
            const [userResult] = await pool.query(
                'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                ['admin', 'admin@company.com', hashedPassword, 'admin']
            );

            await pool.query(
                'INSERT INTO employees (user_id, full_name, email, phone, date_of_birth, department, position, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [userResult.insertId, 'Admin User', 'admin@company.com', '+1234567890', '1990-01-01', 'HR', 'Administrator', '2020-01-01']
            );
            console.log('Admin user created (admin@company.com / admin123)');
        }

        const empPassword = await bcrypt.hash('password123', 10);
        const employees = [
            { username: 'alice', email: 'alice@company.com', name: 'Alice Johnson', phone: '+1234567891', dob: '1992-05-15', dept: 'Engineering', pos: 'Software Developer', hire: '2021-03-10' },
            { username: 'bob', email: 'bob@company.com', name: 'Bob Smith', phone: '+1234567892', dob: '1988-08-22', dept: 'Marketing', pos: 'Marketing Manager', hire: '2020-07-01' },
            { username: 'carol', email: 'carol@company.com', name: 'Carol Williams', phone: '+1234567893', dob: '1995-01-30', dept: 'Engineering', pos: 'Senior Developer', hire: '2019-11-15' },
            { username: 'david', email: 'david@company.com', name: 'David Brown', phone: '+1234567894', dob: '1991-12-10', dept: 'HR', pos: 'HR Specialist', hire: '2022-01-05' },
            { username: 'eva', email: 'eva@company.com', name: 'Eva Martinez', phone: '+1234567895', dob: '1993-07-18', dept: 'Finance', pos: 'Financial Analyst', hire: '2021-06-20' }
        ];

        for (const emp of employees) {
            const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [emp.email]);
            if (existing.length === 0) {
                const [userResult] = await pool.query(
                    'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                    [emp.username, emp.email, empPassword, 'employee']
                );
                await pool.query(
                    'INSERT INTO employees (user_id, full_name, email, phone, date_of_birth, department, position, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [userResult.insertId, emp.name, emp.email, emp.phone, emp.dob, emp.dept, emp.pos, emp.hire]
                );
                console.log(`Created employee: ${emp.name} (${emp.email} / password123)`);
            }
        }

        console.log('Database seeded successfully!');
        console.log('\nLogin credentials:');
        console.log('Admin: admin@company.com / admin123');
        console.log('Employees: [name]@company.com / password123');
    } catch (error) {
        console.error('Seeding error:', error);
    } finally {
        process.exit();
    }
};

seedData();
