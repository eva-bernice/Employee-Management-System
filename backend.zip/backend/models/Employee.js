const pool = require('../config/database');
const { annualLeaveEntitlement } = require('../config/auth');

const EmployeeModel = {
    async findAll() {
        const [rows] = await pool.query(`
            SELECT e.*, u.username, u.role,
                (SELECT COALESCE(SUM(lr.number_of_days), 0)
                 FROM leave_requests lr
                 WHERE lr.employee_id = e.id AND lr.status = 'approved'
                ) as leave_used
            FROM employees e
            LEFT JOIN users u ON e.user_id = u.id
            ORDER BY e.created_at DESC
        `);
        return rows.map(emp => ({
            ...emp,
            leave_entitlement: annualLeaveEntitlement,
            leave_remaining: annualLeaveEntitlement - emp.leave_used
        }));
    },

    async findById(id) {
        const [rows] = await pool.query(`
            SELECT e.*, u.username, u.role,
                (SELECT COALESCE(SUM(lr.number_of_days), 0)
                 FROM leave_requests lr
                 WHERE lr.employee_id = e.id AND lr.status = 'approved'
                ) as leave_used
            FROM employees e
            LEFT JOIN users u ON e.user_id = u.id
            WHERE e.id = ?
        `, [id]);

        if (rows[0]) {
            rows[0].leave_entitlement = annualLeaveEntitlement;
            rows[0].leave_remaining = annualLeaveEntitlement - rows[0].leave_used;
        }

        return rows[0];
    },

    async findByUserId(userId) {
        const [rows] = await pool.query(`
            SELECT e.*,
                (SELECT COALESCE(SUM(lr.number_of_days), 0)
                 FROM leave_requests lr
                 WHERE lr.employee_id = e.id AND lr.status = 'approved'
                ) as leave_used
            FROM employees e
            WHERE e.user_id = ?
        `, [userId]);

        if (rows[0]) {
            rows[0].leave_entitlement = annualLeaveEntitlement;
            rows[0].leave_remaining = annualLeaveEntitlement - rows[0].leave_used;
        }

        return rows[0];
    },

    async create(employeeData) {
        const [result] = await pool.query(
            `INSERT INTO employees (user_id, full_name, email, phone, date_of_birth, department, position, hire_date)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [employeeData.user_id, employeeData.full_name, employeeData.email,
             employeeData.phone, employeeData.date_of_birth, employeeData.department,
             employeeData.position, employeeData.hire_date]
        );
        return { id: result.insertId, ...employeeData };
    },

    async update(id, employeeData) {
        await pool.query(
            `UPDATE employees SET full_name = ?, email = ?, phone = ?, date_of_birth = ?,
             department = ?, position = ?, hire_date = ? WHERE id = ?`,
            [employeeData.full_name, employeeData.email, employeeData.phone,
             employeeData.date_of_birth, employeeData.department, employeeData.position,
             employeeData.hire_date, id]
        );
        return this.findById(id);
    },

    async delete(id) {
        await pool.query('DELETE FROM employees WHERE id = ?', [id]);
    },

    async getLeaveBalance(employeeId) {
        const [rows] = await pool.query(`
            SELECT COALESCE(SUM(number_of_days), 0) as total_used
            FROM leave_requests
            WHERE employee_id = ? AND status = 'approved'
        `, [employeeId]);

        const totalUsed = rows[0].total_used;
        return {
            employee_id: employeeId,
            entitlement: annualLeaveEntitlement,
            used: totalUsed,
            remaining: annualLeaveEntitlement - totalUsed
        };
    },

    async search(query) {
        const [rows] = await pool.query(`
            SELECT e.*, u.username, u.role,
                (SELECT COALESCE(SUM(lr.number_of_days), 0)
                 FROM leave_requests lr
                 WHERE lr.employee_id = e.id AND lr.status = 'approved'
                ) as leave_used
            FROM employees e
            LEFT JOIN users u ON e.user_id = u.id
            WHERE e.full_name LIKE ? OR e.email LIKE ? OR e.department LIKE ?
            ORDER BY e.created_at DESC
        `, [`%${query}%`, `%${query}%`, `%${query}%`]);

        return rows.map(emp => ({
            ...emp,
            leave_entitlement: annualLeaveEntitlement,
            leave_remaining: annualLeaveEntitlement - emp.leave_used
        }));
    }
};

module.exports = EmployeeModel;
