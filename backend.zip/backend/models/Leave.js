const pool = require('../config/database');
const { calculateWorkingDays } = require('../utils/helpers');
const { annualLeaveEntitlement } = require('../config/auth');

const LeaveModel = {
    async create(leaveData) {
        const days = calculateWorkingDays(leaveData.start_date, leaveData.end_date);

        const [result] = await pool.query(
            `INSERT INTO leave_requests (employee_id, start_date, end_date, number_of_days, leave_type, reason)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [leaveData.employee_id, leaveData.start_date, leaveData.end_date,
             days, leaveData.leave_type, leaveData.reason]
        );
        return { id: result.insertId, ...leaveData, number_of_days: days, status: 'pending' };
    },

    async findAll() {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department,
                   u.username as approved_by_name
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            LEFT JOIN users u ON lr.approved_by = u.id
            ORDER BY lr.created_at DESC
        `);
        return rows;
    },

    async findByEmployeeId(employeeId) {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.employee_id = ?
            ORDER BY lr.created_at DESC
        `, [employeeId]);
        return rows;
    },

    async findById(id) {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.id = ?
        `, [id]);
        return rows[0];
    },

    async approve(id, approvedBy) {
        await pool.query(
            `UPDATE leave_requests SET status = 'approved', approved_by = ? WHERE id = ?`,
            [approvedBy, id]
        );
        return this.findById(id);
    },

    async reject(id, approvedBy) {
        await pool.query(
            `UPDATE leave_requests SET status = 'rejected', approved_by = ? WHERE id = ?`,
            [approvedBy, id]
        );
        return this.findById(id);
    },

    async canTakeLeave(employeeId, requestedDays) {
        const [rows] = await pool.query(`
            SELECT COALESCE(SUM(number_of_days), 0) as total_used
            FROM leave_requests
            WHERE employee_id = ? AND status = 'approved'
        `, [employeeId]);

        const totalUsed = rows[0].total_used;
        const remaining = annualLeaveEntitlement - totalUsed;

        return {
            canTake: requestedDays <= remaining,
            totalUsed,
            remaining,
            entitlement: annualLeaveEntitlement
        };
    },

    async getCurrentlyOnLeave() {
        const today = new Date().toISOString().split('T')[0];
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department, e.position
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.status = 'approved'
            AND lr.start_date <= ? AND lr.end_date >= ?
            ORDER BY lr.end_date ASC
        `, [today, today]);
        return rows;
    },

    async getPendingRequests() {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department, e.position
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.status = 'pending'
            ORDER BY lr.created_at ASC
        `);
        return rows;
    },

    async getLeaveStatistics() {
        const today = new Date().toISOString().split('T')[0];

        const [totalEmployees] = await pool.query('SELECT COUNT(*) as count FROM employees');

        const [onLeaveToday] = await pool.query(`
            SELECT COUNT(DISTINCT lr.employee_id) as count
            FROM leave_requests lr
            WHERE lr.status = 'approved'
            AND lr.start_date <= ? AND lr.end_date >= ?
        `, [today, today]);

        const [totalLeaveDaysUsed] = await pool.query(`
            SELECT COALESCE(SUM(number_of_days), 0) as total
            FROM leave_requests
            WHERE status = 'approved'
            AND YEAR(start_date) = YEAR(CURDATE())
        `);

        const [pendingCount] = await pool.query(`
            SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'
        `);

        return {
            totalEmployees: totalEmployees[0].count,
            employeesOnLeaveToday: onLeaveToday[0].count,
            employeesWorkingToday: totalEmployees[0].count - onLeaveToday[0].count,
            totalLeaveDaysUsed: totalLeaveDaysUsed[0].total,
            pendingRequests: pendingCount[0].count
        };
    },

    async getOnLeaveForDate(targetDate) {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department, e.position
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.status = 'approved'
            AND lr.start_date <= ? AND lr.end_date >= ?
            ORDER BY e.full_name ASC
        `, [targetDate, targetDate]);
        return rows;
    },

    async getLeaveDatesForMonth(year, month) {
        const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
        const lastDay = new Date(year, month, 0).getDate();
        const endDate = `${year}-${String(month).padStart(2, '0')}-${lastDay}`;

        const [rows] = await pool.query(`
            SELECT lr.start_date, lr.end_date, lr.employee_id, e.full_name as employee_name
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE lr.status = 'approved'
            AND lr.start_date <= ? AND lr.end_date >= ?
            ORDER BY lr.start_date ASC
        `, [endDate, startDate]);

        const dateMap = {};
        rows.forEach(leave => {
            const start = new Date(Math.max(new Date(leave.start_date), new Date(startDate)));
            const end = new Date(Math.min(new Date(leave.end_date), new Date(endDate)));
            const current = new Date(start);
            while (current <= end) {
                const dateStr = current.toISOString().split('T')[0];
                if (!dateMap[dateStr]) dateMap[dateStr] = [];
                dateMap[dateStr].push(leave.employee_name);
                current.setDate(current.getDate() + 1);
            }
        });

        return dateMap;
    },

    async getMonthlyLeaveReport(year, month) {
        const [rows] = await pool.query(`
            SELECT lr.*, e.full_name as employee_name, e.department
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            WHERE YEAR(lr.start_date) = ? AND MONTH(lr.start_date) = ?
            ORDER BY lr.start_date ASC
        `, [year, month]);
        return rows;
    }
};

module.exports = LeaveModel;
