function calculateWorkingDays(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    let workingDays = 0;

    const current = new Date(start);
    while (current <= end) {
        const dayOfWeek = current.getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
            workingDays++;
        }
        current.setDate(current.getDate() + 1);
    }

    return workingDays;
}

function formatDate(date) {
    return new Date(date).toISOString().split('T')[0];
}

function isDateInRange(date, startDate, endDate) {
    const checkDate = new Date(date);
    const start = new Date(startDate);
    const end = new Date(endDate);
    return checkDate >= start && checkDate <= end;
}

module.exports = { calculateWorkingDays, formatDate, isDateInRange };
