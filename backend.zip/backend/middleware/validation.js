const {
    body,
    param,
    query,
    validationResult
} = require('express-validator');


// =====================================================
// HANDLE VALIDATION ERRORS
// =====================================================
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            errors: errors.array()
        });
    }

    next();
};


// =====================================================
// VALIDATE REGISTRATION
// =====================================================
const validateRegistration = [
    body('username')
        .trim()
        .isLength({ min: 3 })
        .withMessage('Username must be at least 3 characters'),

    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),

    body('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters'),

    body('role')
        .isIn(['admin', 'manager', 'employee'])
        .withMessage('Invalid role'),

    handleValidationErrors
];


// =====================================================
// VALIDATE LOGIN
// =====================================================
const validateLogin = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),

    body('password')
        .notEmpty()
        .withMessage('Password is required'),

    handleValidationErrors
];


// =====================================================
// VALIDATE EMPLOYEE
// =====================================================
const validateEmployee = [
    body('full_name')
        .trim()
        .notEmpty()
        .withMessage('Full name is required'),

    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),

    body('phone')
        .trim()
        .notEmpty()
        .withMessage('Phone is required'),

    body('date_of_birth')
        .isISO8601()
        .withMessage('Valid date of birth is required'),

    body('department')
        .trim()
        .notEmpty()
        .withMessage('Department is required'),

    body('position')
        .trim()
        .notEmpty()
        .withMessage('Position is required'),

    body('hire_date')
        .isISO8601()
        .withMessage('Valid hire date is required'),

    handleValidationErrors
];


// =====================================================
// VALIDATE LEAVE REQUEST
// =====================================================
//
// IMPORTANT:
// employee_id is NOT required here.
//
// For an employee, the backend automatically gets
// employee_id using the logged-in user's JWT:
//
//     req.user.id
//
// Admin/manager can still provide employee_id when
// submitting a leave request for another employee.
// =====================================================
const validateLeaveRequest = [

    body('start_date')
        .isISO8601()
        .withMessage('Valid start date is required'),

    body('end_date')
        .isISO8601()
        .withMessage('Valid end date is required'),

    body('leave_type')
        .isIn([
            'annual',
            'sick',
            'personal',
            'maternity',
            'paternity'
        ])
        .withMessage('Invalid leave type'),

    body('reason')
        .trim()
        .notEmpty()
        .withMessage('Reason is required'),

    handleValidationErrors
];


module.exports = {
    validateRegistration,
    validateLogin,
    validateEmployee,
    validateLeaveRequest,
    handleValidationErrors
};