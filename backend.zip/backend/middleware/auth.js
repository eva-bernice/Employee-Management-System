const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/auth');

// =====================================================
// AUTHENTICATE USER
// =====================================================
const authenticate = (req, res, next) => {
    const authHeader = req.headers.authorization;

    // Check if Authorization header exists
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
            message: 'Access denied. No token provided.'
        });
    }

    // Get token
    const token = authHeader.split(' ')[1];

    try {
        // Verify token
        const decoded = jwt.verify(token, jwtSecret);

        // Store decoded user information
        req.user = decoded;

        next();
    } catch (error) {
        console.error('Authentication error:', error.message);

        return res.status(401).json({
            message: 'Invalid or expired token.'
        });
    }
};


// =====================================================
// AUTHORIZE USER ROLE
// =====================================================
const authorize = (...roles) => {
    return (req, res, next) => {
        // User must be authenticated first
        if (!req.user) {
            return res.status(401).json({
                message: 'Access denied. Not authenticated.'
            });
        }

        // Check user's role
        if (!roles.includes(req.user.role)) {
            console.log(
                `Authorization failed. User role: "${req.user.role}", Required roles: ${roles.join(', ')}`
            );

            return res.status(403).json({
                message: 'Access denied. Insufficient permissions.'
            });
        }

        next();
    };
};


module.exports = {
    authenticate,
    authorize
};