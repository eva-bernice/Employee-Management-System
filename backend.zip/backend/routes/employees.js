const express = require('express');
const router = express.Router();

const EmployeeModel = require('../models/Employee');
const AuthModel = require('../models/Auth');

const { validateEmployee } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');

// =====================================================
// GET CURRENT LOGGED-IN EMPLOYEE
// IMPORTANT: This route must come before /:id
// =====================================================
router.get('/me', authenticate, async (req, res) => {
    try {
        const employee = await EmployeeModel.findByUserId(req.user.id);

        if (!employee) {
            return res.status(404).json({
                message: 'Employee profile not found'
            });
        }

        res.json(employee);
    } catch (error) {
        console.error('Get employee profile error:', error);

        res.status(500).json({
            message: 'Internal server error'
        });
    }
});


// =====================================================
// GET ALL EMPLOYEES
// ADMIN AND MANAGER ONLY
// =====================================================
router.get(
    '/',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const { search } = req.query;

            let employees;

            if (search) {
                employees = await EmployeeModel.search(search);
            } else {
                employees = await EmployeeModel.findAll();
            }

            res.json(employees);
        } catch (error) {
            console.error('Get employees error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// GET EMPLOYEE BY ID
// =====================================================
router.get('/:id', authenticate, async (req, res) => {
    try {
        const employee = await EmployeeModel.findById(req.params.id);

        if (!employee) {
            return res.status(404).json({
                message: 'Employee not found'
            });
        }

        res.json(employee);
    } catch (error) {
        console.error('Get employee error:', error);

        res.status(500).json({
            message: 'Internal server error'
        });
    }
});


// =====================================================
// CREATE EMPLOYEE
// ADMIN ONLY
// =====================================================
router.post(
    '/',
    authenticate,
    authorize('admin'),
    validateEmployee,
    async (req, res) => {
        try {
            const {
                username,
                email,
                password,
                full_name,
                phone,
                date_of_birth,
                department,
                position,
                hire_date
            } = req.body;

            let userId = null;

            // Create login account if credentials are provided
            if (username && email && password) {
                const user = await AuthModel.create({
                    username,
                    email,
                    password,
                    role: 'employee'
                });

                userId = user.id;
            }

            const employee = await EmployeeModel.create({
                user_id: userId,
                full_name,
                email,
                phone,
                date_of_birth,
                department,
                position,
                hire_date
            });

            res.status(201).json({
                message: 'Employee created successfully',
                employee
            });
        } catch (error) {
            console.error('Create employee error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// UPDATE EMPLOYEE
// ADMIN ONLY
// =====================================================
router.put(
    '/:id',
    authenticate,
    authorize('admin'),
    validateEmployee,
    async (req, res) => {
        try {
            const employee = await EmployeeModel.findById(req.params.id);

            if (!employee) {
                return res.status(404).json({
                    message: 'Employee not found'
                });
            }

            const updated = await EmployeeModel.update(
                req.params.id,
                req.body
            );

            res.json({
                message: 'Employee updated successfully',
                employee: updated
            });
        } catch (error) {
            console.error('Update employee error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// DELETE EMPLOYEE
// ADMIN ONLY
// =====================================================
router.delete(
    '/:id',
    authenticate,
    authorize('admin'),
    async (req, res) => {
        try {
            const employee = await EmployeeModel.findById(req.params.id);

            if (!employee) {
                return res.status(404).json({
                    message: 'Employee not found'
                });
            }

            await EmployeeModel.delete(req.params.id);

            res.json({
                message: 'Employee deleted successfully'
            });
        } catch (error) {
            console.error('Delete employee error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// GET LEAVE BALANCE
// =====================================================
router.get(
    '/:id/leave-balance',
    authenticate,
    async (req, res) => {
        try {
            const balance = await EmployeeModel.getLeaveBalance(
                req.params.id
            );

            res.json(balance);
        } catch (error) {
            console.error('Get leave balance error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


module.exports = router;