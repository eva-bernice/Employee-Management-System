const express = require('express');
const router = express.Router();

const LeaveModel = require('../models/Leave');
const EmployeeModel = require('../models/Employee');

const {
    validateLeaveRequest
} = require('../middleware/validation');

const {
    authenticate,
    authorize
} = require('../middleware/auth');

const {
    calculateWorkingDays
} = require('../utils/helpers');


// =====================================================
// GET LEAVE REQUESTS
// =====================================================
router.get('/', authenticate, async (req, res) => {
    try {
        let leaves;

        // Employee can only see their own leave requests
        if (req.user.role === 'employee') {
            const employee = await EmployeeModel.findByUserId(req.user.id);

            if (!employee) {
                return res.status(404).json({
                    message: 'Employee profile not found'
                });
            }

            leaves = await LeaveModel.findByEmployeeId(employee.id);
        }

        // Admin and manager can see all leave requests
        else if (
            req.user.role === 'admin' ||
            req.user.role === 'manager'
        ) {
            leaves = await LeaveModel.findAll();
        }

        // Other roles are not allowed
        else {
            return res.status(403).json({
                message: 'Access denied. Insufficient permissions.'
            });
        }

        res.json(leaves);

    } catch (error) {
        console.error('Get leaves error:', error);

        res.status(500).json({
            message: 'Internal server error'
        });
    }
});


// =====================================================
// CREATE LEAVE REQUEST
// =====================================================
router.post(
    '/',
    authenticate,
    validateLeaveRequest,
    async (req, res) => {
        try {
            const {
                employee_id,
                start_date,
                end_date,
                leave_type,
                reason
            } = req.body;

            let finalEmployeeId;


            // =================================================
            // EMPLOYEE
            // Automatically determine employee ID
            // from the logged-in user's account.
            // =================================================
            if (req.user.role === 'employee') {
                const employee =
                    await EmployeeModel.findByUserId(req.user.id);

                if (!employee) {
                    return res.status(404).json({
                        message: 'Employee profile not found'
                    });
                }

                finalEmployeeId = employee.id;
            }


            // =================================================
            // ADMIN / MANAGER
            // They can submit leave for a selected employee.
            // =================================================
            else if (
                req.user.role === 'admin' ||
                req.user.role === 'manager'
            ) {
                if (!employee_id) {
                    return res.status(400).json({
                        message: 'Valid employee ID is required'
                    });
                }

                finalEmployeeId = employee_id;
            }


            // =================================================
            // OTHER ROLES
            // =================================================
            else {
                return res.status(403).json({
                    message: 'Access denied. Insufficient permissions.'
                });
            }


            // =================================================
            // VALIDATE DATES
            // =================================================
            if (!start_date || !end_date) {
                return res.status(400).json({
                    message: 'Start date and end date are required'
                });
            }

            if (new Date(end_date) < new Date(start_date)) {
                return res.status(400).json({
                    message: 'End date must be after start date'
                });
            }


            // =================================================
            // CALCULATE WORKING DAYS
            // =================================================
            const requestedDays =
                calculateWorkingDays(start_date, end_date);

            if (requestedDays <= 0) {
                return res.status(400).json({
                    message:
                        'Leave request must include at least one working day'
                });
            }


            // =================================================
            // CHECK LEAVE BALANCE
            // =================================================
            const leaveCheck =
                await LeaveModel.canTakeLeave(
                    finalEmployeeId,
                    requestedDays
                );

            if (
                !leaveCheck.canTake ||
                requestedDays > leaveCheck.remaining
            ) {
                return res.status(400).json({
                    message:
                        `Leave request exceeds remaining annual leave. ` +
                        `Only ${leaveCheck.remaining} days are available.`,
                    remaining: leaveCheck.remaining,
                    requested: requestedDays
                });
            }


            // =================================================
            // CREATE LEAVE REQUEST
            // =================================================
            const leave = await LeaveModel.create({
                employee_id: finalEmployeeId,
                start_date,
                end_date,
                leave_type,
                reason
            });


            res.status(201).json({
                message: 'Leave request submitted successfully',
                leave
            });

        } catch (error) {
            console.error('Create leave error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// APPROVE LEAVE REQUEST
// ADMIN / MANAGER ONLY
// =====================================================
router.put(
    '/:id/approve',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const leave =
                await LeaveModel.findById(req.params.id);

            if (!leave) {
                return res.status(404).json({
                    message: 'Leave request not found'
                });
            }

            if (leave.status !== 'pending') {
                return res.status(400).json({
                    message:
                        'Can only approve pending requests'
                });
            }

            const leaveCheck =
                await LeaveModel.canTakeLeave(
                    leave.employee_id,
                    0
                );

            if (leave.number_of_days > leaveCheck.remaining) {
                return res.status(400).json({
                    message:
                        `Cannot approve. Employee only has ` +
                        `${leaveCheck.remaining} days remaining.`
                });
            }

            const approved =
                await LeaveModel.approve(
                    req.params.id,
                    req.user.id
                );

            res.json({
                message: 'Leave request approved',
                leave: approved
            });

        } catch (error) {
            console.error('Approve leave error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// REJECT LEAVE REQUEST
// ADMIN / MANAGER ONLY
// =====================================================
router.put(
    '/:id/reject',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const leave =
                await LeaveModel.findById(req.params.id);

            if (!leave) {
                return res.status(404).json({
                    message: 'Leave request not found'
                });
            }

            const rejected =
                await LeaveModel.reject(
                    req.params.id,
                    req.user.id
                );

            res.json({
                message: 'Leave request rejected',
                leave: rejected
            });

        } catch (error) {
            console.error('Reject leave error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// GET PENDING LEAVE REQUESTS
// ADMIN / MANAGER ONLY
// =====================================================
router.get(
    '/pending',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const pending =
                await LeaveModel.getPendingRequests();

            res.json(pending);

        } catch (error) {
            console.error('Get pending leaves error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// =====================================================
// CHECK LEAVE AVAILABILITY
// =====================================================
router.get(
    '/check/:employeeId',
    authenticate,
    async (req, res) => {
        try {
            const {
                start_date,
                end_date
            } = req.query;

            if (!start_date || !end_date) {
                return res.status(400).json({
                    message:
                        'Start date and end date are required'
                });
            }

            const days =
                calculateWorkingDays(
                    start_date,
                    end_date
                );

            const check =
                await LeaveModel.canTakeLeave(
                    req.params.employeeId,
                    days
                );

            res.json({
                ...check,
                requested_days: days
            });

        } catch (error) {
            console.error('Check leave error:', error);

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


module.exports = router;