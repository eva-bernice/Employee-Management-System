const express = require('express');
const router = express.Router();

const LeaveModel = require('../models/Leave');
const EmployeeModel = require('../models/Employee');
const { authenticate, authorize } = require('../middleware/auth');

// ==========================================
// DAILY LEAVE REPORT
// ==========================================
router.get(
    '/daily',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const targetDate =
                req.query.date ||
                new Date().toISOString().split('T')[0];

            const onLeave =
                await LeaveModel.getOnLeaveForDate(targetDate);

            const allEmployees =
                await EmployeeModel.findAll();

            const onLeaveIds =
                onLeave.map(leave => leave.employee_id);

            const notOnLeave =
                allEmployees.filter(
                    employee => !onLeaveIds.includes(employee.id)
                );

            res.json({
                date: targetDate,

                employeesOnLeave: onLeave.map(employee => ({
                    id: employee.employee_id,
                    name: employee.employee_name,
                    department: employee.department,
                    position: employee.position,
                    leave_start: employee.start_date,
                    leave_end: employee.end_date,
                    leave_type: employee.leave_type,

                    days_remaining:
                        Math.ceil(
                            (
                                new Date(employee.end_date) -
                                new Date(targetDate)
                            ) /
                            (1000 * 60 * 60 * 24)
                        ) + 1
                })),

                employeesWorking: notOnLeave.map(employee => ({
                    id: employee.id,
                    name: employee.full_name,
                    department: employee.department,
                    position: employee.position
                }))
            });

        } catch (error) {
            console.error(
                'Get daily report error:',
                error
            );

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// ==========================================
// DASHBOARD REPORT
// ==========================================
router.get(
    '/dashboard',
    authenticate,
    async (req, res) => {
        try {
            const stats =
                await LeaveModel.getLeaveStatistics();

            const pending =
                await LeaveModel.getPendingRequests();

            const onLeave =
                await LeaveModel.getCurrentlyOnLeave();

            res.json({
                statistics: stats,
                pendingRequests: pending,
                currentlyOnLeave: onLeave
            });

        } catch (error) {
            console.error(
                'Get dashboard error:',
                error
            );

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// ==========================================
// MONTHLY LEAVE REPORT
// ==========================================
router.get(
    '/monthly',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const year =
                parseInt(
                    req.query.year ||
                    new Date().getFullYear()
                );

            const month =
                parseInt(
                    req.query.month ||
                    new Date().getMonth() + 1
                );

            const report =
                await LeaveModel.getMonthlyLeaveReport(
                    year,
                    month
                );

            res.json(report);

        } catch (error) {
            console.error(
                'Get monthly report error:',
                error
            );

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


// ==========================================
// LEAVE DATES FOR CALENDAR
// ==========================================
router.get(
    '/leave-dates',
    authenticate,
    authorize('admin', 'manager'),
    async (req, res) => {
        try {
            const year =
                parseInt(
                    req.query.year ||
                    new Date().getFullYear()
                );

            const month =
                parseInt(
                    req.query.month ||
                    new Date().getMonth() + 1
                );

            const dates =
                await LeaveModel.getLeaveDatesForMonth(
                    year,
                    month
                );

            res.json(dates);

        } catch (error) {
            console.error(
                'Get leave dates error:',
                error
            );

            res.status(500).json({
                message: 'Internal server error'
            });
        }
    }
);


module.exports = router;