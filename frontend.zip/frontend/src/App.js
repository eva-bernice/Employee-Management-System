import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import EmployeeForm from './pages/EmployeeForm';
import EmployeeProfile from './pages/EmployeeProfile';
import LeaveManagement from './pages/LeaveManagement';
import LeaveRequest from './pages/LeaveRequest';
import DailyReport from './pages/DailyReport';
import MyLeave from './pages/MyLeave';

const ProtectedRoute = ({ children }) => {
    const { user, loading } = useAuth();
    if (loading) return <div className="loading">Loading...</div>;
    return user ? children : <Navigate to="/login" />;
};

const AdminRoute = ({ children }) => {
    const { user, loading, isAdmin } = useAuth();
    if (loading) return <div className="loading">Loading...</div>;
    if (!user) return <Navigate to="/login" />;
    if (!isAdmin) return <Navigate to="/dashboard" />;
    return children;
};

const ManagerRoute = ({ children }) => {
    const { user, loading, isAdmin, isManager } = useAuth();
    if (loading) return <div className="loading">Loading...</div>;
    if (!user) return <Navigate to="/login" />;
    if (!isAdmin && !isManager) return <Navigate to="/dashboard" />;
    return children;
};

const AppLayout = () => {
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const { user } = useAuth();

    return (
        <div className="app-layout">
            <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
            <div className="main-content">
                <Header onMenuClick={() => setSidebarOpen(true)} />
                <div className="page-content">
                    <Routes>
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/employees" element={
                            <ManagerRoute><Employees /></ManagerRoute>
                        } />
                        <Route path="/employees/new" element={
                            <AdminRoute><EmployeeForm /></AdminRoute>
                        } />
                        <Route path="/employees/:id" element={<EmployeeProfile />} />
                        <Route path="/employees/:id/edit" element={
                            <AdminRoute><EmployeeForm /></AdminRoute>
                        } />
                        <Route path="/leave" element={<LeaveManagement />} />
                        <Route path="/leave/request" element={<LeaveRequest />} />
                        <Route path="/leave/request/:employeeId" element={
                            <ManagerRoute><LeaveRequest /></ManagerRoute>
                        } />
                        <Route path="/daily-report" element={
                            <ManagerRoute><DailyReport /></ManagerRoute>
                        } />
                        <Route path="/my-leave" element={<MyLeave />} />
                        <Route path="/" element={<Navigate to="/dashboard" />} />
                        <Route path="*" element={<Navigate to="/dashboard" />} />
                    </Routes>
                </div>
            </div>
        </div>
    );
};

const App = () => {
    return (
        <AuthProvider>
            <Router>
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/*" element={
                        <ProtectedRoute>
                            <AppLayout />
                        </ProtectedRoute>
                    } />
                </Routes>
            </Router>
        </AuthProvider>
    );
};

export default App;
