import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const LeaveRequest = () => {
    const navigate = useNavigate();
    const { user } = useAuth();

    const isEmployee = user?.role === 'employee';

    const [employees, setEmployees] = useState([]);
    const [currentEmployee, setCurrentEmployee] = useState(null);

    const [formData, setFormData] = useState({
        employee_id: '',
        start_date: '',
        end_date: '',
        leave_type: 'annual',
        reason: ''
    });

    const [errors, setErrors] = useState({});
    const [leaveInfo, setLeaveInfo] = useState(null);
    const [loading, setLoading] = useState(false);
    const [fetchLoading, setFetchLoading] = useState(true);

    /*
     * Load employee information.
     *
     * Employee:
     * - Get ONLY their own employee profile.
     *
     * Admin/Manager:
     * - Get all employees so they can select one if needed.
     */
    useEffect(() => {
        const loadEmployeeData = async () => {
            try {
                if (isEmployee) {
                    const data = await api.employees.getMe();

                    setCurrentEmployee(data);

                    setFormData(prev => ({
                        ...prev,
                        employee_id: data.id
                    }));
                } else {
                    const data = await api.employees.getAll();
                    setEmployees(data);
                }
            } catch (err) {
                console.error('Error loading employee data:', err);

                setErrors({
                    submit:
                        err.message ||
                        'Unable to load employee information.'
                });
            } finally {
                setFetchLoading(false);
            }
        };

        loadEmployeeData();
    }, [isEmployee]);

    /*
     * Check leave balance whenever employee/date information changes.
     */
    useEffect(() => {
        if (
            formData.employee_id &&
            formData.start_date &&
            formData.end_date
        ) {
            api.leave
                .check(
                    formData.employee_id,
                    formData.start_date,
                    formData.end_date
                )
                .then(data => {
                    setLeaveInfo(data);
                })
                .catch(err => {
                    console.error('Leave check error:', err);
                    setLeaveInfo(null);
                });
        } else {
            setLeaveInfo(null);
        }
    }, [
        formData.employee_id,
        formData.start_date,
        formData.end_date
    ]);

    const today = new Date().toISOString().split('T')[0];

    /*
     * Validate form.
     */
    const validate = () => {
        const newErrors = {};

        /*
         * Only admin/manager needs an employee ID
         * selected from the form.
         *
         * Employee ID is automatically supplied by
         * the logged-in employee.
         */
        if (!isEmployee && !formData.employee_id) {
            newErrors.employee_id = 'Employee is required';
        }

        if (!formData.start_date) {
            newErrors.start_date = 'Start date is required';
        } else if (formData.start_date < today) {
            newErrors.start_date =
                'Start date cannot be in the past';
        }

        if (!formData.end_date) {
            newErrors.end_date = 'End date is required';
        } else if (formData.end_date < today) {
            newErrors.end_date =
                'End date cannot be in the past';
        } else if (
            formData.start_date &&
            formData.end_date &&
            new Date(formData.end_date) <
                new Date(formData.start_date)
        ) {
            newErrors.end_date =
                'End date must be after start date';
        }

        if (!formData.reason.trim()) {
            newErrors.reason = 'Reason is required';
        }

        if (
            leaveInfo &&
            leaveInfo.requested_days > leaveInfo.remaining
        ) {
            newErrors.submit =
                `Leave request exceeds remaining annual leave. ` +
                `Only ${leaveInfo.remaining} days are available.`;
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    };

    /*
     * Handle form changes.
     */
    const handleChange = e => {
        const { name, value } = e.target;

        /*
         * Prevent past dates.
         */
        if (
            (name === 'start_date' ||
                name === 'end_date') &&
            value &&
            value < today
        ) {
            return;
        }

        setFormData(prev => {
            const updated = {
                ...prev,
                [name]: value
            };

            /*
             * If start date changes and becomes later
             * than the end date, automatically move
             * the end date to the start date.
             */
            if (
                name === 'start_date' &&
                updated.end_date &&
                updated.end_date < value
            ) {
                updated.end_date = value;
            }

            return updated;
        });

        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }

        if (errors.submit) {
            setErrors(prev => ({
                ...prev,
                submit: ''
            }));
        }
    };

    /*
     * Submit leave request.
     */
    const handleSubmit = async e => {
        e.preventDefault();

        if (!validate()) {
            return;
        }

        setLoading(true);

        try {
            /*
             * IMPORTANT:
             *
             * For employees we DON'T send employee_id.
             * The backend gets the employee ID from
             * req.user.id.
             *
             * Admin/manager can send employee_id.
             */
            let requestData;

            if (isEmployee) {
                requestData = {
                    start_date: formData.start_date,
                    end_date: formData.end_date,
                    leave_type: formData.leave_type,
                    reason: formData.reason
                };
            } else {
                requestData = formData;
            }

            await api.leave.create(requestData);

            alert('Leave request submitted successfully!');

            navigate('/leave');
        } catch (err) {
            console.error('Submit leave error:', err);

            setErrors({
                submit:
                    err.message ||
                    'Failed to submit leave request.'
            });
        } finally {
            setLoading(false);
        }
    };

    /*
     * Loading screen.
     */
    if (fetchLoading) {
        return (
            <div className="loading">
                Loading...
            </div>
        );
    }

    /*
     * Determine which employee's balance to display.
     */
    const selectedEmployee = isEmployee
        ? currentEmployee
        : employees.find(
              employee =>
                  employee.id ===
                  parseInt(formData.employee_id)
          );

    return (
        <div className="page">
            <h1>Request Leave</h1>

            {errors.submit && (
                <div className="alert alert-error">
                    {errors.submit}
                </div>
            )}

            <form
                className="form-card"
                onSubmit={handleSubmit}
            >
                <div className="form-grid">

                    {/* 
                     * EMPLOYEE VIEW
                     *
                     * Employee does NOT select themselves.
                     * Their identity comes from login.
                     */}
                    {isEmployee && currentEmployee && (
                        <div className="form-group">
                            <label>Employee</label>

                            <input
                                type="text"
                                value={`${currentEmployee.full_name} (${currentEmployee.department})`}
                                disabled
                            />

                            <small>
                                You are requesting leave for
                                yourself.
                            </small>
                        </div>
                    )}

                    {/* 
                     * ADMIN / MANAGER VIEW
                     *
                     * Only these roles can select an employee.
                     */}
                    {!isEmployee && (
                        <div className="form-group">
                            <label>Employee *</label>

                            <select
                                name="employee_id"
                                value={
                                    formData.employee_id
                                }
                                onChange={handleChange}
                            >
                                <option value="">
                                    Select employee
                                </option>

                                {employees.map(employee => (
                                    <option
                                        key={employee.id}
                                        value={employee.id}
                                    >
                                        {employee.full_name} (
                                        {employee.department})
                                    </option>
                                ))}
                            </select>

                            {errors.employee_id && (
                                <span className="error-text">
                                    {errors.employee_id}
                                </span>
                            )}
                        </div>
                    )}

                    {/* Leave Type */}
                    <div className="form-group">
                        <label>
                            Leave Type *
                        </label>

                        <select
                            name="leave_type"
                            value={formData.leave_type}
                            onChange={handleChange}
                        >
                            <option value="annual">
                                Annual
                            </option>

                            <option value="sick">
                                Sick
                            </option>

                            <option value="personal">
                                Personal
                            </option>

                            <option value="maternity">
                                Maternity
                            </option>

                            <option value="paternity">
                                Paternity
                            </option>
                        </select>
                    </div>

                    {/* Start Date */}
                    <div className="form-group">
                        <label>
                            Start Date *
                        </label>

                        <input
                            type="date"
                            name="start_date"
                            value={formData.start_date}
                            onChange={handleChange}
                            min={today}
                        />

                        {errors.start_date && (
                            <span className="error-text">
                                {errors.start_date}
                            </span>
                        )}
                    </div>

                    {/* End Date */}
                    <div className="form-group">
                        <label>
                            End Date *
                        </label>

                        <input
                            type="date"
                            name="end_date"
                            value={formData.end_date}
                            onChange={handleChange}
                            min={
                                formData.start_date ||
                                today
                            }
                        />

                        {errors.end_date && (
                            <span className="error-text">
                                {errors.end_date}
                            </span>
                        )}
                    </div>

                    {/* Reason */}
                    <div className="form-group full-width">
                        <label>
                            Reason *
                        </label>

                        <textarea
                            name="reason"
                            value={formData.reason}
                            onChange={handleChange}
                            rows="3"
                            placeholder="Enter the reason for your leave..."
                        />

                        {errors.reason && (
                            <span className="error-text">
                                {errors.reason}
                            </span>
                        )}
                    </div>
                </div>

                {/* Leave Balance */}
                {selectedEmployee && (
                    <div className="leave-info-panel">
                        <h4>
                            Leave Balance
                        </h4>

                        <div className="balance-info">
                            <div>
                                <span>
                                    Entitlement:
                                </span>

                                <strong>
                                    {
                                        selectedEmployee.leave_entitlement
                                    }{' '}
                                    days
                                </strong>
                            </div>

                            <div>
                                <span>
                                    Used:
                                </span>

                                <strong>
                                    {
                                        selectedEmployee.leave_used
                                    }{' '}
                                    days
                                </strong>
                            </div>

                            <div>
                                <span>
                                    Remaining:
                                </span>

                                <strong className="text-success">
                                    {
                                        selectedEmployee.leave_remaining
                                    }{' '}
                                    days
                                </strong>
                            </div>
                        </div>
                    </div>
                )}

                {/* Leave Request Check */}
                {leaveInfo && (
                    <div
                        className={`leave-check-panel ${
                            leaveInfo.canTake
                                ? 'panel-success'
                                : 'panel-danger'
                        }`}
                    >
                        <h4>
                            Leave Request Check
                        </h4>

                        <div className="balance-info">
                            <div>
                                <span>
                                    Requested Days:
                                </span>

                                <strong>
                                    {
                                        leaveInfo.requested_days
                                    }
                                </strong>
                            </div>

                            <div>
                                <span>
                                    Available Days:
                                </span>

                                <strong>
                                    {
                                        leaveInfo.remaining
                                    }
                                </strong>
                            </div>

                            <div>
                                <span>
                                    Status:
                                </span>

                                <strong
                                    className={
                                        leaveInfo.canTake
                                            ? 'text-success'
                                            : 'text-danger'
                                    }
                                >
                                    {leaveInfo.canTake
                                        ? 'Can proceed'
                                        : 'Exceeds available days'}
                                </strong>
                            </div>
                        </div>
                    </div>
                )}

                {/* Buttons */}
                <div className="form-actions">
                    <button
                        type="button"
                        className="btn btn-outline"
                        onClick={() =>
                            navigate(-1)
                        }
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        className="btn btn-primary"
                        disabled={loading}
                    >
                        {loading
                            ? 'Submitting...'
                            : 'Submit Request'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default LeaveRequest;