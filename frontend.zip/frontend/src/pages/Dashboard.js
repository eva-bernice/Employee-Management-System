import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

const Dashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.reports.getDashboard()
            .then(data => setStats(data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <div className="loading">Loading dashboard...</div>;
    if (!stats) return <div className="error">Failed to load dashboard</div>;

    const { statistics, pendingRequests, currentlyOnLeave } = stats;

    return (
        <div className="dashboard">
            <h1>Dashboard</h1>

            <div className="stats-grid">
                <div className="stat-card stat-blue">
                    <div className="stat-number">{statistics.totalEmployees}</div>
                    <div className="stat-label">Total Employees</div>
                </div>
                <div className="stat-card stat-green">
                    <div className="stat-number">{statistics.employeesOnLeaveToday}</div>
                    <div className="stat-label">On Leave Today</div>
                </div>
                <div className="stat-card stat-purple">
                    <div className="stat-number">{statistics.employeesWorkingToday}</div>
                    <div className="stat-label">Working Today</div>
                </div>
                <div className="stat-card stat-orange">
                    <div className="stat-number">{statistics.pendingRequests}</div>
                    <div className="stat-label">Pending Requests</div>
                </div>
            </div>

            <div className="dashboard-grid">
                <div className="dashboard-card">
                    <h3>Currently On Leave</h3>
                    {currentlyOnLeave.length === 0 ? (
                        <p className="text-muted">No employees on leave today</p>
                    ) : (
                        <div className="list">
                            {currentlyOnLeave.map(leave => (
                                <div key={leave.id} className="list-item">
                                    <div>
                                        <strong>{leave.employee_name}</strong>
                                        <span className="text-muted">{leave.department}</span>
                                    </div>
                                    <span className="badge badge-warning">On Leave</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="dashboard-card">
                    <h3>Pending Leave Requests</h3>
                    {pendingRequests.length === 0 ? (
                        <p className="text-muted">No pending requests</p>
                    ) : (
                        <div className="list">
                            {pendingRequests.map(leave => (
                                <div key={leave.id} className="list-item">
                                    <div>
                                        <strong>{leave.employee_name}</strong>
                                        <span className="text-muted">
                                            {leave.number_of_days} days ({leave.leave_type})
                                        </span>
                                    </div>
                                    <Link to="/leave" className="btn btn-sm btn-outline">Review</Link>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <div className="quick-actions">
                <Link to="/leave/request" className="btn btn-primary">Request Leave</Link>
                <Link to="/daily-report" className="btn btn-outline">View Daily Report</Link>
                <Link to="/employees" className="btn btn-outline">Manage Employees</Link>
            </div>
        </div>
    );
};

export default Dashboard;
