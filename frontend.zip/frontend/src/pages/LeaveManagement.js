import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const LeaveManagement = () => {
    const [leaves, setLeaves] = useState([]);
    const [loading, setLoading] = useState(true);
    const { canApprove } = useAuth();

    useEffect(() => {
        api.leave.getAll()
            .then(data => setLeaves(data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, []);

    const handleApprove = async (id) => {
        try {
            await api.leave.approve(id);
            setLeaves(leaves.map(l => l.id === id ? { ...l, status: 'approved' } : l));
        } catch (err) {
            alert(err.message);
        }
    };

    const handleReject = async (id) => {
        try {
            await api.leave.reject(id);
            setLeaves(leaves.map(l => l.id === id ? { ...l, status: 'rejected' } : l));
        } catch (err) {
            alert(err.message);
        }
    };

    if (loading) return <div className="loading">Loading leave requests...</div>;

    const pending = leaves.filter(l => l.status === 'pending');
    const processed = leaves.filter(l => l.status !== 'pending');

    return (
        <div className="page">
            <h1>Leave Requests</h1>

            {canApprove && pending.length > 0 && (
                <>
                    <h2>Pending Requests ({pending.length})</h2>
                    <div className="table-container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Department</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Days</th>
                                    <th>Type</th>
                                    <th>Reason</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {pending.map(leave => (
                                    <tr key={leave.id}>
                                        <td>{leave.employee_name}</td>
                                        <td>{leave.department}</td>
                                        <td>{new Date(leave.start_date).toLocaleDateString()}</td>
                                        <td>{new Date(leave.end_date).toLocaleDateString()}</td>
                                        <td>{leave.number_of_days}</td>
                                        <td><span className="badge badge-info">{leave.leave_type}</span></td>
                                        <td className="reason-cell">{leave.reason}</td>
                                        <td className="actions">
                                            <button
                                                className="btn btn-sm btn-success"
                                                onClick={() => handleApprove(leave.id)}
                                            >Approve</button>
                                            <button
                                                className="btn btn-sm btn-danger"
                                                onClick={() => handleReject(leave.id)}
                                            >Reject</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}

            <h2>All Requests</h2>
            {leaves.length === 0 ? (
                <p className="text-muted">No leave requests found</p>
            ) : (
                <div className="table-container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Department</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Days</th>
                                <th>Type</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {leaves.map(leave => (
                                <tr key={leave.id}>
                                    <td>{leave.employee_name}</td>
                                    <td>{leave.department}</td>
                                    <td>{new Date(leave.start_date).toLocaleDateString()}</td>
                                    <td>{new Date(leave.end_date).toLocaleDateString()}</td>
                                    <td>{leave.number_of_days}</td>
                                    <td><span className="badge badge-info">{leave.leave_type}</span></td>
                                    <td>
                                        <span className={`badge badge-${leave.status === 'approved' ? 'success' : leave.status === 'rejected' ? 'danger' : 'warning'}`}>
                                            {leave.status}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default LeaveManagement;
