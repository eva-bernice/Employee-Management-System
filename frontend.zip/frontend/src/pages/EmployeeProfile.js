import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const EmployeeProfile = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { isAdmin } = useAuth();
    const [employee, setEmployee] = useState(null);
    const [leaves, setLeaves] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        Promise.all([
            api.employees.getById(id),
            api.leave.getAll()
        ])
            .then(([empData, leaveData]) => {
                setEmployee(empData);
                setLeaves(leaveData.filter(l => l.employee_id === parseInt(id)));
            })
            .catch(err => {
                console.error(err);
                navigate('/employees');
            })
            .finally(() => setLoading(false));
    }, [id, navigate]);

    if (loading) return <div className="loading">Loading profile...</div>;
    if (!employee) return <div className="error">Employee not found</div>;

    return (
        <div className="page">
            <div className="page-header">
                <h1>{employee.full_name}</h1>
                <div>
                    {isAdmin && (
                        <Link to={`/employees/${id}/edit`} className="btn btn-outline">Edit</Link>
                    )}
                    <Link to="/employees" className="btn btn-outline">Back to List</Link>
                </div>
            </div>

            <div className="profile-grid">
                <div className="profile-card">
                    <h3>Personal Information</h3>
                    <div className="info-grid">
                        <div className="info-item">
                            <label>Email</label>
                            <span>{employee.email}</span>
                        </div>
                        <div className="info-item">
                            <label>Phone</label>
                            <span>{employee.phone}</span>
                        </div>
                        <div className="info-item">
                            <label>Date of Birth</label>
                            <span>{new Date(employee.date_of_birth).toLocaleDateString()}</span>
                        </div>
                        <div className="info-item">
                            <label>Hire Date</label>
                            <span>{new Date(employee.hire_date).toLocaleDateString()}</span>
                        </div>
                    </div>
                </div>

                <div className="profile-card">
                    <h3>Work Information</h3>
                    <div className="info-grid">
                        <div className="info-item">
                            <label>Department</label>
                            <span>{employee.department}</span>
                        </div>
                        <div className="info-item">
                            <label>Position</label>
                            <span>{employee.position}</span>
                        </div>
                    </div>
                </div>

                <div className="profile-card leave-balance-card">
                    <h3>Leave Balance (Annual)</h3>
                    <div className="leave-balance-display">
                        <div className="balance-circle">
                            <div className="balance-number">{employee.leave_remaining}</div>
                            <div className="balance-label">Days Remaining</div>
                        </div>
                        <div className="balance-details">
                            <div className="balance-row">
                                <span>Entitlement:</span>
                                <strong>{employee.leave_entitlement} days</strong>
                            </div>
                            <div className="balance-row">
                                <span>Used:</span>
                                <strong className="text-danger">{employee.leave_used} days</strong>
                            </div>
                            <div className="balance-row">
                                <span>Remaining:</span>
                                <strong className="text-success">{employee.leave_remaining} days</strong>
                            </div>
                        </div>
                    </div>
                    <Link to={`/leave/request/${id}`} className="btn btn-primary btn-sm" style={{ marginTop: '1rem' }}>
                        Request Leave
                    </Link>
                </div>
            </div>

            <div className="profile-card">
                <h3>Leave History</h3>
                {leaves.length === 0 ? (
                    <p className="text-muted">No leave records found</p>
                ) : (
                    <div className="table-container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Days</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {leaves.map(leave => (
                                    <tr key={leave.id}>
                                        <td>{new Date(leave.start_date).toLocaleDateString()}</td>
                                        <td>{new Date(leave.end_date).toLocaleDateString()}</td>
                                        <td>{leave.number_of_days}</td>
                                        <td><span className="badge badge-info">{leave.leave_type}</span></td>
                                        <td>
                                            <span className={`badge badge-${leave.status === 'approved' ? 'success' : leave.status === 'rejected' ? 'danger' : 'warning'}`}>
                                                {leave.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};

export default EmployeeProfile;
