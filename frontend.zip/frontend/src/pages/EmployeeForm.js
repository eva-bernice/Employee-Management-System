import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

const EmployeeForm = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = Boolean(id);

    const [formData, setFormData] = useState({
        full_name: '', email: '', phone: '', date_of_birth: '',
        department: '', position: '', hire_date: '',
        username: '', password: ''
    });
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const [fetchLoading, setFetchLoading] = useState(isEdit);

    useEffect(() => {
        if (isEdit) {
            api.employees.getById(id)
                .then(data => {
                    setFormData({
                        full_name: data.full_name,
                        email: data.email,
                        phone: data.phone,
                        date_of_birth: data.date_of_birth?.split('T')[0] || '',
                        department: data.department,
                        position: data.position,
                        hire_date: data.hire_date?.split('T')[0] || '',
                        username: '',
                        password: ''
                    });
                })
                .catch(err => {
                    alert(err.message);
                    navigate('/employees');
                })
                .finally(() => setFetchLoading(false));
        }
    }, [id, isEdit, navigate]);

    const validate = () => {
        const newErrors = {};

        if (!formData.full_name.trim()) newErrors.full_name = 'Full name is required';
        if (!formData.email.trim()) newErrors.email = 'Email is required';
        else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
        if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
        if (!formData.date_of_birth) newErrors.date_of_birth = 'Date of birth is required';
        if (!formData.department.trim()) newErrors.department = 'Department is required';
        if (!formData.position.trim()) newErrors.position = 'Position is required';
        if (!formData.hire_date) newErrors.hire_date = 'Hire date is required';

        if (!isEdit) {
            if (!formData.username.trim()) newErrors.username = 'Username is required';
            else if (formData.username.length < 3) newErrors.username = 'Username must be at least 3 characters';
            if (!formData.password) newErrors.password = 'Password is required';
            else if (formData.password.length < 6) newErrors.password = 'Password must be at least 6 characters';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        setLoading(true);
        try {
            if (isEdit) {
                await api.employees.update(id, formData);
            } else {
                await api.employees.create(formData);
            }
            navigate('/employees');
        } catch (err) {
            setErrors({ submit: err.message });
        } finally {
            setLoading(false);
        }
    };

    if (fetchLoading) return <div className="loading">Loading employee...</div>;

    return (
        <div className="page">
            <h1>{isEdit ? 'Edit Employee' : 'Add Employee'}</h1>

            {errors.submit && <div className="alert alert-error">{errors.submit}</div>}

            <form className="form-card" onSubmit={handleSubmit}>
                <div className="form-grid">
                    <div className="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="full_name" value={formData.full_name} onChange={handleChange} />
                        {errors.full_name && <span className="error-text">{errors.full_name}</span>}
                    </div>

                    <div className="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" value={formData.email} onChange={handleChange} />
                        {errors.email && <span className="error-text">{errors.email}</span>}
                    </div>

                    <div className="form-group">
                        <label>Phone *</label>
                        <input type="text" name="phone" value={formData.phone} onChange={handleChange} />
                        {errors.phone && <span className="error-text">{errors.phone}</span>}
                    </div>

                    <div className="form-group">
                        <label>Date of Birth *</label>
                        <input type="date" name="date_of_birth" value={formData.date_of_birth} onChange={handleChange} />
                        {errors.date_of_birth && <span className="error-text">{errors.date_of_birth}</span>}
                    </div>

                    <div className="form-group">
                        <label>Department *</label>
                        <input type="text" name="department" value={formData.department} onChange={handleChange} />
                        {errors.department && <span className="error-text">{errors.department}</span>}
                    </div>

                    <div className="form-group">
                        <label>Position *</label>
                        <input type="text" name="position" value={formData.position} onChange={handleChange} />
                        {errors.position && <span className="error-text">{errors.position}</span>}
                    </div>

                    <div className="form-group">
                        <label>Hire Date *</label>
                        <input type="date" name="hire_date" value={formData.hire_date} onChange={handleChange} />
                        {errors.hire_date && <span className="error-text">{errors.hire_date}</span>}
                    </div>

                    {!isEdit && (
                        <>
                            <div className="form-group">
                                <label>Username *</label>
                                <input type="text" name="username" value={formData.username} onChange={handleChange} />
                                {errors.username && <span className="error-text">{errors.username}</span>}
                            </div>

                            <div className="form-group">
                                <label>Password *</label>
                                <input type="password" name="password" value={formData.password} onChange={handleChange} />
                                {errors.password && <span className="error-text">{errors.password}</span>}
                            </div>
                        </>
                    )}
                </div>

                <div className="form-actions">
                    <button type="button" className="btn btn-outline" onClick={() => navigate('/employees')}>Cancel</button>
                    <button type="submit" className="btn btn-primary" disabled={loading}>
                        {loading ? 'Saving...' : isEdit ? 'Update Employee' : 'Add Employee'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default EmployeeForm;
