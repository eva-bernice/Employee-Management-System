import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const MyLeave = () => {
    const [employee, setEmployee] = useState(null);
    const [leaves, setLeaves] = useState([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuth();

    useEffect(() => {
        Promise.all([
            api.employees.getProfile(),
            api.leave.getAll()
        ])
            .then(([empData, leaveData]) => {
                setEmployee(empData);
                setLeaves(leaveData);
            })
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <div className="loading">Loading your leave information...</div>;

    return (
        <div className="page">
            <h1>My Leave</h1>

            {employee ? (
                <>
                    <div className="leave-balance-banner">
                        <div className="balance-item">
                            <span className="balance-value">{employee.leave_entitlement}</span>
                            <span className="balance-label">Annual Entitlement</span>
                        </div>
                        <div className="balance-item">
                            <span className="balance-value text-danger">{employee.leave_used}</span>
                            <span className="balance-label">Days Used</span>
                        </div>
                        <div className="balance-item">
                            <span className="balance-value text-success">{employee.leave_remaining}</span>
                            <span className="balance-label">Days Remaining</span>
                        </div>
                    </div>

                    <div style={{ marginTop: '1.5rem' }}>
                        <Link to="/leave/request" className="btn btn-primary">Request Leave</Link>
                    </div>
                </>
            ) : (
                <div className="alert alert-info">Employee profile not found. Please contact HR.</div>
            )}

            <h2 style={{ marginTop: '2rem' }}>My Leave History</h2>
            {leaves.length === 0 ? (
                <div className="empty-state">
                    <p>No leave records found.</p>
                    <Link to="/leave/request" className="btn btn-primary">Request Your First Leave</Link>
                </div>
            ) : (
                <div className="table-container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Days</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            {leaves.map(leave => (
                                <tr key={leave.id}>
                                    <td>{new Date(leave.start_date).toLocaleDateString()}</td>
                                    <td>{new Date(leave.end_date).toLocaleDateString()}</td>
                                    <td>{leave.number_of_days}</td>
                                    <td><span className="badge badge-info">{leave.leave_type}</span></td>
                                    <td>
                                        <span className={`badge badge-${leave.status === 'approved' ? 'success' : leave.status === 'rejected' ? 'danger' : 'warning'}`}>
                                            {leave.status}
                                        </span>
                                    </td>
                                    <td className="reason-cell">{leave.reason}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default MyLeave;
