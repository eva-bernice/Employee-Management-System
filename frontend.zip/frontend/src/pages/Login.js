import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            await login(email, password);
            navigate('/dashboard');
        } catch (err) {
            setError(err.message || 'Login failed');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-page">
            <div className="login-left">
                <div className="login-brand">
                    <div className="login-logo">EMS</div>
                    <h2>Employment<br />Management<br />System</h2>
                    <p>Manage employees, track leave, and generate reports — all in one place.</p>
                </div>
                <div className="login-features">
                    <div className="login-feature">
                        <span className="feature-icon">&#9632;</span>
                        <span>Employee Management</span>
                    </div>
                    <div className="login-feature">
                        <span className="feature-icon">&#9632;</span>
                        <span>Leave Tracking</span>
                    </div>
                    <div className="login-feature">
                        <span className="feature-icon">&#9632;</span>
                        <span>Daily Reports</span>
                    </div>
                </div>
            </div>

            <div className="login-right">
                <div className="login-card">
                    <div className="login-header">
                        <div className="login-icon">&#9733;</div>
                        <h1>Welcome Back</h1>
                        <p>Sign in to your account</p>
                    </div>

                    {error && <div className="alert alert-error">{error}</div>}

                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>Email Address</label>
                            <div className="input-wrapper">
                                <span className="input-icon">&#9993;</span>
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="you@company.com"
                                    required
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <div className="input-wrapper">
                                <span className="input-icon">&#9919;</span>
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Enter your password"
                                    required
                                />
                                <button
                                    type="button"
                                    className="toggle-password"
                                    onClick={() => setShowPassword(!showPassword)}
                                >
                                    {showPassword ? '&#9737;' : '&#9738;'}
                                </button>
                            </div>
                        </div>

                        <button type="submit" className="btn btn-primary btn-full login-btn" disabled={loading}>
                            {loading ? (
                                <span className="login-spinner" />
                            ) : (
                                'Sign In'
                            )}
                        </button>
                    </form>

    
                </div>
            </div>
        </div>
    );
};

export default Login;
