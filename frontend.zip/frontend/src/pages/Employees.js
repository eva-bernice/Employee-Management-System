import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const Employees = () => {
    const [employees, setEmployees] = useState([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const { isAdmin } = useAuth();

    const fetchEmployees = (searchQuery = '') => {
        setLoading(true);
        api.employees.getAll(searchQuery)
            .then(data => setEmployees(data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        fetchEmployees();
    }, []);

    const handleSearch = (e) => {
        e.preventDefault();
        fetchEmployees(search);
    };

    const handleDelete = async (id, name) => {
        if (window.confirm(`Are you sure you want to delete ${name}?`)) {
            try {
                await api.employees.delete(id);
                setEmployees(employees.filter(emp => emp.id !== id));
            } catch (err) {
                alert(err.message);
            }
        }
    };

    return (
        <div className="page">
            <div className="page-header">
                <h1>Employees</h1>
                {isAdmin && (
                    <Link to="/employees/new" className="btn btn-primary">Add Employee</Link>
                )}
            </div>

            <form className="search-form" onSubmit={handleSearch}>
                <input
                    type="text"
                    placeholder="Search employees..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="search-input"
                />
                <button type="submit" className="btn btn-outline">Search</button>
            </form>

            {loading ? (
                <div className="loading">Loading employees...</div>
            ) : (
                <div className="table-container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Department</th>
                                <th>Position</th>
                                <th>Leave Used</th>
                                <th>Remaining</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {employees.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="text-center">No employees found</td>
                                </tr>
                            ) : (
                                employees.map(emp => (
                                    <tr key={emp.id}>
                                        <td>
                                            <Link to={`/employees/${emp.id}`} className="link">
                                                {emp.full_name}
                                            </Link>
                                        </td>
                                        <td>{emp.department}</td>
                                        <td>{emp.position}</td>
                                        <td>{emp.leave_used} days</td>
                                        <td>
                                            <span className={emp.leave_remaining <= 3 ? 'text-danger' : 'text-success'}>
                                                {emp.leave_remaining} days
                                            </span>
                                        </td>
                                        <td className="actions">
                                            <Link to={`/employees/${emp.id}`} className="btn btn-sm btn-outline">View</Link>
                                            {isAdmin && (
                                                <>
                                                    <Link to={`/employees/${emp.id}/edit`} className="btn btn-sm btn-outline">Edit</Link>
                                                    <button
                                                        className="btn btn-sm btn-danger"
                                                        onClick={() => handleDelete(emp.id, emp.full_name)}
                                                    >Delete</button>
                                                </>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default Employees;
