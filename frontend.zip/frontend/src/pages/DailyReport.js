import React, { useState, useEffect, useCallback } from 'react';
import api from '../services/api';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const formatLocalDate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
};

const startOfDay = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate());

const DailyReport = () => {
    const today = startOfDay(new Date());
    const [selectedDate, setSelectedDate] = useState(today);
    const [report, setReport] = useState(null);
    const [leaveDates, setLeaveDates] = useState({});
    const [loading, setLoading] = useState(true);
    const [calendarMonth, setCalendarMonth] = useState(today.getMonth());
    const [calendarYear, setCalendarYear] = useState(today.getFullYear());

    const fetchReport = useCallback((date) => {
        setLoading(true);
        const dateStr = formatLocalDate(date);
        api.reports.getDaily(dateStr)
            .then(data => setReport(data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, []);

    const fetchLeaveDates = useCallback((year, month) => {
        api.reports.getLeaveDates(year, month + 1)
            .then(data => setLeaveDates(data))
            .catch(err => console.error(err));
    }, []);

    useEffect(() => {
        fetchReport(selectedDate);
    }, [selectedDate, fetchReport]);

    useEffect(() => {
        fetchLeaveDates(calendarYear, calendarMonth);
    }, [calendarYear, calendarMonth, fetchLeaveDates]);

    const handleDateClick = (date) => {
        setSelectedDate(date);
        setCalendarMonth(date.getMonth());
        setCalendarYear(date.getFullYear());
    };

    const navigateMonth = (direction) => {
        const newDate = new Date(calendarYear, calendarMonth + direction, 1);
        setCalendarMonth(newDate.getMonth());
        setCalendarYear(newDate.getFullYear());
    };

    const goToToday = () => {
        const now = startOfDay(new Date());
        setSelectedDate(now);
        setCalendarMonth(now.getMonth());
        setCalendarYear(now.getFullYear());
    };

    const renderCalendar = () => {
        const firstDay = new Date(calendarYear, calendarMonth, 1).getDay();
        const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
        const todayStr = formatLocalDate(today);
        const selectedStr = formatLocalDate(selectedDate);

        const cells = [];

        for (let i = 0; i < firstDay; i++) {
            cells.push(<div key={`empty-${i}`} className="calendar-cell empty" />);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const date = startOfDay(new Date(calendarYear, calendarMonth, day));
            const dateStr = formatLocalDate(date);
            const isToday = dateStr === todayStr;
            const isSelected = dateStr === selectedStr;
            const hasLeave = leaveDates[dateStr] && leaveDates[dateStr].length > 0;

            let classes = 'calendar-cell';
            if (isToday) classes += ' today';
            if (isSelected) classes += ' selected';
            if (hasLeave) classes += ' has-leave';

            cells.push(
                <button
                    type="button"
                    key={day}
                    className={classes}
                    onClick={() => handleDateClick(date)}
                    title={hasLeave ? `${leaveDates[dateStr].length} employee(s) on leave` : `View report for ${dateStr}`}
                    aria-label={`View report for ${dateStr}`}
                    aria-pressed={isSelected}
                >
                    <span className="calendar-day">{day}</span>
                    {hasLeave && (
                        <span className="calendar-dot">
                            {leaveDates[dateStr].length}
                        </span>
                    )}
                </button>
            );
        }

        return cells;
    };

    return (
        <div className="page">
            <h1>Daily Leave Report</h1>

            <div className="report-layout">
                <div className="calendar-section">
                    <div className="calendar-card">
                        <div className="calendar-header">
                            <button type="button" className="btn btn-sm btn-outline" onClick={() => navigateMonth(-1)}>&#8249;</button>
                            <h3>{MONTHS[calendarMonth]} {calendarYear}</h3>
                            <button type="button" className="btn btn-sm btn-outline" onClick={() => navigateMonth(1)}>&#8250;</button>
                        </div>

                        <div className="calendar-today-row">
                            <button type="button" className="btn btn-sm btn-primary" onClick={goToToday}>Today</button>
                        </div>

                        <div className="calendar-days-header">
                            {DAYS.map(day => (
                                <div key={day} className="calendar-day-name">{day}</div>
                            ))}
                        </div>

                        <div className="calendar-grid">
                            {renderCalendar()}
                        </div>

                        <div className="calendar-legend">
                            <div className="legend-item">
                                <span className="legend-dot today-dot" /> Today
                            </div>
                            <div className="legend-item">
                                <span className="legend-dot leave-dot" /> On Leave
                            </div>
                            <div className="legend-item">
                                <span className="legend-dot selected-dot" /> Selected
                            </div>
                        </div>
                    </div>
                </div>

                <div className="report-content">
                    <div className="report-date-header">
                        <h2>
                            {selectedDate.toLocaleDateString('en-US', {
                                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
                            })}
                        </h2>
                    </div>

                    {loading ? (
                        <div className="loading">Loading report...</div>
                    ) : !report ? (
                        <div className="error">Failed to load report</div>
                    ) : (
                        <>
                            <div className="report-stats-row">
                                <div className="report-stat report-stat-on">
                                    <span className="report-stat-num">{report.employeesOnLeave.length}</span>
                                    <span className="report-stat-label">On Leave</span>
                                </div>
                                <div className="report-stat report-stat-off">
                                    <span className="report-stat-num">{report.employeesWorking.length}</span>
                                    <span className="report-stat-label">Working</span>
                                </div>
                                <div className="report-stat report-stat-total">
                                    <span className="report-stat-num">{report.employeesOnLeave.length + report.employeesWorking.length}</span>
                                    <span className="report-stat-label">Total</span>
                                </div>
                            </div>

                            <div className="report-card">
                                <h3 className="status-on-leave">
                                    Employees On Leave ({report.employeesOnLeave.length})
                                </h3>
                                {report.employeesOnLeave.length === 0 ? (
                                    <p className="text-muted">No employees on leave this day</p>
                                ) : (
                                    <div className="table-container">
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Department</th>
                                                    <th>Position</th>
                                                    <th>Leave Period</th>
                                                    <th>Days Left</th>
                                                    <th>Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {report.employeesOnLeave.map(emp => (
                                                    <tr key={emp.id}>
                                                        <td>{emp.name}</td>
                                                        <td>{emp.department}</td>
                                                        <td>{emp.position}</td>
                                                        <td>
                                                            {new Date(emp.leave_start).toLocaleDateString()} - {new Date(emp.leave_end).toLocaleDateString()}
                                                        </td>
                                                        <td>{emp.days_remaining} days</td>
                                                        <td><span className="badge badge-info">{emp.leave_type}</span></td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>

                            <div className="report-card">
                                <h3 className="status-working">
                                    Employees Working ({report.employeesWorking.length})
                                </h3>
                                {report.employeesWorking.length === 0 ? (
                                    <p className="text-muted">All employees are on leave</p>
                                ) : (
                                    <div className="table-container">
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Department</th>
                                                    <th>Position</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {report.employeesWorking.map(emp => (
                                                    <tr key={emp.id}>
                                                        <td>{emp.name}</td>
                                                        <td>{emp.department}</td>
                                                        <td>{emp.position}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DailyReport;
