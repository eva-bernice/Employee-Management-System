const API_URL = 'http://localhost:5000/api';

const getHeaders = () => {
    const token = localStorage.getItem('token');

    return {
        'Content-Type': 'application/json',
        ...(token && {
            Authorization: `Bearer ${token}`
        })
    };
};

const handleResponse = async (response) => {
    let data;

    try {
        data = await response.json();
    } catch (error) {
        throw new Error('Invalid server response');
    }

    if (!response.ok) {
        throw new Error(
            data.message ||
            data.errors?.[0]?.msg ||
            'Request failed'
        );
    }

    return data;
};

const api = {
    // =========================
    // AUTH
    // =========================
    auth: {
        login: (credentials) =>
            fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify(credentials)
            }).then(handleResponse),

        register: (userData) =>
            fetch(`${API_URL}/auth/register`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify(userData)
            }).then(handleResponse),

        me: () =>
            fetch(`${API_URL}/auth/me`, {
                headers: getHeaders()
            }).then(handleResponse)
    },

    // =========================
    // EMPLOYEES
    // =========================
    employees: {
        // Get all employees
        getAll: (search = '') =>
            fetch(
                `${API_URL}/employees${
                    search
                        ? `?search=${encodeURIComponent(search)}`
                        : ''
                }`,
                {
                    headers: getHeaders()
                }
            ).then(handleResponse),

        // Get one employee by ID
        getById: (id) =>
            fetch(`${API_URL}/employees/${id}`, {
                headers: getHeaders()
            }).then(handleResponse),

        // Get currently logged-in employee
        getMe: () =>
            fetch(`${API_URL}/employees/me`, {
                headers: getHeaders()
            }).then(handleResponse),

        // Alias - also gets currently logged-in employee
        getProfile: () =>
            fetch(`${API_URL}/employees/me`, {
                headers: getHeaders()
            }).then(handleResponse),

        // Create employee
        create: (data) =>
            fetch(`${API_URL}/employees`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify(data)
            }).then(handleResponse),

        // Update employee
        update: (id, data) =>
            fetch(`${API_URL}/employees/${id}`, {
                method: 'PUT',
                headers: getHeaders(),
                body: JSON.stringify(data)
            }).then(handleResponse),

        // Delete employee
        delete: (id) =>
            fetch(`${API_URL}/employees/${id}`, {
                method: 'DELETE',
                headers: getHeaders()
            }).then(handleResponse),

        // Get leave balance
        getLeaveBalance: (id) =>
            fetch(`${API_URL}/employees/${id}/leave-balance`, {
                headers: getHeaders()
            }).then(handleResponse)
    },

    // =========================
    // LEAVE
    // =========================
    leave: {
        // Get leave requests
        getAll: () =>
            fetch(`${API_URL}/leave`, {
                headers: getHeaders()
            }).then(handleResponse),

        // Create leave request
        create: (data) =>
            fetch(`${API_URL}/leave`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify(data)
            }).then(handleResponse),

        // Approve leave
        approve: (id) =>
            fetch(`${API_URL}/leave/${id}/approve`, {
                method: 'PUT',
                headers: getHeaders()
            }).then(handleResponse),

        // Reject leave
        reject: (id) =>
            fetch(`${API_URL}/leave/${id}/reject`, {
                method: 'PUT',
                headers: getHeaders()
            }).then(handleResponse),

        // Get pending leave
        getPending: () =>
            fetch(`${API_URL}/leave/pending`, {
                headers: getHeaders()
            }).then(handleResponse),

        // Check leave dates
        check: (employeeId, startDate, endDate) =>
            fetch(
                `${API_URL}/leave/check/${employeeId}?start_date=${encodeURIComponent(
                    startDate
                )}&end_date=${encodeURIComponent(endDate)}`,
                {
                    headers: getHeaders()
                }
            ).then(handleResponse)
    },

    // =========================
    // REPORTS
    // =========================
    reports: {
        getDaily: (date = '') =>
            fetch(
                `${API_URL}/reports/daily${
                    date ? `?date=${encodeURIComponent(date)}` : ''
                }`,
                {
                    headers: getHeaders()
                }
            ).then(handleResponse),

        getDashboard: () =>
            fetch(`${API_URL}/reports/dashboard`, {
                headers: getHeaders()
            }).then(handleResponse),

        getMonthly: (year, month) =>
            fetch(
                `${API_URL}/reports/monthly?year=${year}&month=${month}`,
                {
                    headers: getHeaders()
                }
            ).then(handleResponse),

        getLeaveDates: (year, month) =>
            fetch(
                `${API_URL}/reports/leave-dates?year=${year}&month=${month}`,
                {
                    headers: getHeaders()
                }
            ).then(handleResponse)
    }
};

export default api;