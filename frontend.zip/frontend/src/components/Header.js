import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Header = ({ onMenuClick }) => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <header className="header">
            <button className="menu-btn" onClick={onMenuClick}>&#9776;</button>
            <div className="header-right">
                <span className="header-user">{user?.username}</span>
                <button className="btn btn-outline btn-sm" onClick={handleLogout}>Logout</button>
            </div>
        </header>
    );
};

export default Header;
