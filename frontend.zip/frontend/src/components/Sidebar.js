import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Sidebar = ({ isOpen, onClose }) => {
    const { user, isAdmin, canApprove } = useAuth();

    return (
        <>
            {isOpen && <div className="sidebar-overlay" onClick={onClose} />}
            <aside className={`sidebar ${isOpen ? 'sidebar-open' : ''}`}>
                <div className="sidebar-header">
                    <h2>EMS</h2>
                    <button className="sidebar-close" onClick={onClose}>&times;</button>
                </div>

                <nav className="sidebar-nav">
                    <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                        <span className="nav-icon">&#9632;</span> Dashboard
                    </NavLink>

                    {canApprove && (
                        <NavLink to="/employees" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                            <span className="nav-icon">&#9787;</span> Employees
                        </NavLink>
                    )}

                    <NavLink to="/my-leave" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                        <span className="nav-icon">&#9998;</span> My Leave
                    </NavLink>

                    <NavLink to="/leave" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                        <span className="nav-icon">&#9733;</span> Leave Requests
                    </NavLink>

                    <NavLink to="/leave/request" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                        <span className="nav-icon">&#10010;</span> Request Leave
                    </NavLink>

                    {canApprove && (
                        <NavLink to="/daily-report" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={onClose}>
                            <span className="nav-icon">&#9783;</span> Daily Report
                        </NavLink>
                    )}
                </nav>

                <div className="sidebar-footer">
                    <div className="user-info">
                        <div className="user-avatar">{user?.username?.[0]?.toUpperCase()}</div>
                        <div>
                            <div className="user-name">{user?.username}</div>
                            <div className="user-role">{user?.role}</div>
                        </div>
                    </div>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
